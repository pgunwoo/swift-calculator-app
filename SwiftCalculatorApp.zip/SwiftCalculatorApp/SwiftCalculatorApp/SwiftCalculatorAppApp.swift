//
//  SwiftCalculatorAppApp.swift
//  SwiftCalculatorApp
//
//  Created by 박건우 on 8/30/24.
//

import SwiftUI

@main
struct SwiftCalculatorAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
